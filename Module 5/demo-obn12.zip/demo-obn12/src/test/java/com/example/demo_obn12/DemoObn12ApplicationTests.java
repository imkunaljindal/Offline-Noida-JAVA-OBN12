package com.example.demo_obn12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoObn12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
