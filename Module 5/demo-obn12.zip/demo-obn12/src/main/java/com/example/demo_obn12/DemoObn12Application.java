package com.example.demo_obn12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoObn12Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoObn12Application.class, args);
	}

}
