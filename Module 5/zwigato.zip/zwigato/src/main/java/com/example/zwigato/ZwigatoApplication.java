package com.example.zwigato;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZwigatoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZwigatoApplication.class, args);
	}

}
