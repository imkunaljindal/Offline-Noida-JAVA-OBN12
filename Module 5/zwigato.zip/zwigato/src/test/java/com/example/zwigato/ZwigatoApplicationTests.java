package com.example.zwigato;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZwigatoApplicationTests {

	@Test
	void contextLoads() {
	}

}
