package com.example.accioShop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AccioShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(AccioShopApplication.class, args);
	}

}
