package com.example.accioShop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccioShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
